lightUpdate()

